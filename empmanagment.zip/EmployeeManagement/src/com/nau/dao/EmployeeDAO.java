package com.nau.dao;

import com.nau.model.Employee;

public class EmployeeDAO {

	Employee[] employees = new Employee[100];

	public EmployeeDAO() {
		employees[0] = new Employee(0, "NAUSHAD");
		employees[1] = new Employee(1, "AKHTAR");
	}

	public void displayEmployees() {
		for (Employee emp : employees) {
			if (emp != null) {
				System.out.println(emp);
			} 
		}
	}

	public void saveEmployee(Employee employee) {
		int count = 0;
		for (Employee emp : employees) {
			if (emp != null) {
				count++;
			}
		}
		employees[count] = employee;
		displayEmployees();
	}

	public static void main(String[] args) {
		EmployeeDAO dao = new EmployeeDAO();
		dao.saveEmployee(new Employee(3, "asdf"));
		System.out.println("--------------------");
		dao.saveEmployee(new Employee(5, "hhh"));
	}
}
