package com.nau.dao;

import com.nau.model.Employee;

public class EmployeeDAO {

	Employee[] employees = new Employee[100];

	public EmployeeDAO() {
		employees[0] = new Employee(0, "NAUSHAD");
		employees[1] = new Employee(1, "AKHTAR");
	}

	public Employee[] displayEmployees() {
		
		return employees;
//		int count=0;
//		for (Employee emp : employees) {
//			
//			if (emp != null) {
//				count++;
//				System.out.println(emp);
//			}
//			
//		}
		
	}

	public Employee displayEmployeeWithId(int id) {
		boolean flag = false;
		Employee employee = null;
		for (Employee emp : employees) {
			if (emp == null) {

			} else {
				if (emp.getId() == id) {
					employee = emp;
					flag = true;
				}
			}
		}
		if (flag) {
			return employee;
			//System.out.println("Employee found : " + employee);
		} else {
			return null;
		}
	}

	public void saveEmployee(Employee employee) {
		int count = 0;
		for (Employee emp : employees) {
			if (emp != null) {
				count++;
			}
		}
		employees[count] = employee;
		displayEmployees();
	}

	public static void main(String[] args) {
		EmployeeDAO dao = new EmployeeDAO();
		// dao.saveEmployee(new Employee(3, "asdf"));
		System.out.println("--------------------");
		// dao.saveEmployee(new Employee(5, "hhh"));
		Employee e = dao.displayEmployeeWithId(2);
		if(e!=null) {
			System.out.println(e);
		}else {
			System.out.println("Not Found");
		}
		
	}
}
