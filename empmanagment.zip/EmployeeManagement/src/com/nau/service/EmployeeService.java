package com.nau.service;

import com.nau.dao.EmployeeDAO;
import com.nau.model.Employee;

public class EmployeeService {
	EmployeeDAO dao = new EmployeeDAO();
	public void addEmployee(Employee employee) {
		String name = employee.getName();
		String uname = name.toUpperCase();
		employee.setName(uname);
		System.out.println("Added Employee " + employee);
		
		dao.saveEmployee(employee);
	}
	public Employee[] displayEmployees() {
		Employee employees[] = dao.displayEmployees();
		return employees;
	}
	public Employee displayEmpWithId(int id) {
		
		return dao.displayEmployeeWithId(id);
		
	}
}
