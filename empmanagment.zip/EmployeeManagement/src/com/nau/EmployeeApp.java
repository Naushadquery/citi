package com.nau;

import com.nau.presentation.EmployeeView;

public class EmployeeApp {
	
	public static void main(String[] args) {
		
		new EmployeeView();
		
	}

}
