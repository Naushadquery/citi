package com.nau.presentation;

import java.util.Scanner;

import com.nau.model.Employee;
import com.nau.service.EmployeeService;

public class EmployeeView {
	
	EmployeeService employeeService = new EmployeeService(); // fridge
	//API CAll // Service //  SOA // 
	Scanner scanner = new Scanner(System.in);

	public EmployeeView() {
		doTask();
	}
	private void doTask() {
		System.out.println("Do Task");
		System.out.println("1.Add Employee");
		System.out.println("2.Delete Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.View Employee with Id");//
		System.out.println("5.View All Employee");
		System.out.println("6.EXIT");
		System.out.println("Enter Option : ");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1: {
			addEmployee();
			break;
		}
		case 2: {
			deleteEmployee();
			break;
		}
		case 4: {
			viewEmployeeByEmployeeId();
			break;
		}
		case 5 :{
			displayEmployees();
			break;
		}
		case 6: {
			System.out.println("Thanks for using the APP");
			System.exit(0);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choice);
		}
	}

	private void viewEmployeeByEmployeeId() {
		System.out.println("Enter Id : ");
		int id = scanner.nextInt();
		Employee e = employeeService.displayEmpWithId(id);
		if(e!=null) {
			System.out.println(e);
		}else {
			System.out.println("Not Found");
		}
		doTask();
	}

	private void displayEmployees() {
		Employee[] employees= employeeService.displayEmployees();
		System.out.println("Id \t Name"  );
		for (Employee emp : employees) {
			if (emp != null) {
				System.out.println(emp.getId() +"\t" + emp.getName());
			}
			
		}
		doTask();
		
	}

	private void deleteEmployee() {
		
	}

	private void addEmployee() {
		System.out.println("Enter Id");
		int id = scanner.nextInt();
		System.out.println("Enter Name");
		String name = scanner.next();
		Employee employee = new Employee(id, name);
	
		employeeService.addEmployee(employee);
		System.out.println("Do you want to add more employee Y/N");
		String ans = scanner.next();
		if(ans.equalsIgnoreCase("Y")) {
			addEmployee();
		}else {
			doTask();
		}
		
	}

}
