package com.naushad.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naushad.dao.EmployeeDAO;
import com.naushad.dto.EmployeeDTO;
import com.naushad.entity.EmployeeEntity;


@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@Override
	public EmployeeDTO getEmployee(Integer id) {
		EmployeeEntity employeeEntity = employeeDAO.getEmployee(id);
		ModelMapper mapper = new ModelMapper();
		EmployeeDTO employeeDTO = mapper.map(employeeEntity, EmployeeDTO.class);
		return employeeDTO;
	}
}
