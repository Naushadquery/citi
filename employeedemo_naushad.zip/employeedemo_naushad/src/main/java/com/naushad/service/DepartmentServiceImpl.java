package com.naushad.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naushad.dao.DepartmentDAO;

@Service
public class DepartmentServiceImpl implements DapartmentService{

	@Autowired
	private DepartmentDAO departmentDAO;
	
	
	
}
