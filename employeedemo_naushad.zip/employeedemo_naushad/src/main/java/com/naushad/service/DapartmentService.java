package com.naushad.service;

public interface DapartmentService {

}
