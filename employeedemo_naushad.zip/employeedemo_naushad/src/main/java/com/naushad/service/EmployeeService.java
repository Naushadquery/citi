package com.naushad.service;

import org.springframework.stereotype.Service;

import com.naushad.dto.EmployeeDTO;


public interface EmployeeService {
	
	public EmployeeDTO getEmployee(Integer id) ;

}
