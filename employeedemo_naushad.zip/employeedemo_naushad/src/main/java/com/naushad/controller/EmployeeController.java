package com.naushad.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.naushad.dto.EmployeeDTO;
import com.naushad.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping(value="/getemployeebyid/{id}")
	public EmployeeDTO getEmployeeById(@PathVariable Integer id) {
		EmployeeDTO employeeDTO = employeeService.getEmployee(id);
		return employeeDTO;
	}
	
	@PostMapping(value="/addemployee")
	public EmployeeDTO addEmployee(@RequestBody EmployeeDTO dto) {
		System.out.println(dto);
		return dto;
	}
}
