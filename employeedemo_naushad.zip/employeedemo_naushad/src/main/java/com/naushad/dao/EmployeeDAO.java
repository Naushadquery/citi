package com.naushad.dao;

import com.naushad.entity.EmployeeEntity;

public interface EmployeeDAO {
	
	public EmployeeEntity getEmployee(Integer id);

}
