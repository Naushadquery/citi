package com.naushad.dao;

public interface DepartmentDAO {

}