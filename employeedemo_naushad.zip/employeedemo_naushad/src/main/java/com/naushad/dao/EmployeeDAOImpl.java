package com.naushad.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.naushad.entity.EmployeeEntity;
import com.naushad.repo.EmployeeRepository;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public EmployeeEntity getEmployee(Integer id) {
		return employeeRepository.findById(id).get();
	}

}
