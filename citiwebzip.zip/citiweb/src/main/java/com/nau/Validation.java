package com.nau;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/va")
public class Validation extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		System.out.println("GET CALLED");
		String userid = request.getParameter("userid");
		String password = request.getParameter("pwd");
		System.out.println(userid + "  : "  + password);
		if(userid.equals(password)) {
			out.print("<h1> Welcome " + userid.toUpperCase() + " to Citibank</h1>");
		}else {
			out.print("<h1> Sorry " + userid.toUpperCase() + " , Invalid user</h1>");

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("POST CALLED");
		doGet(request, response);
	}

}
