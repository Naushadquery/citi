package com.naushad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.naushad.dto.EmployeeDTO;
import com.naushad.service.EmployeeService;
import com.naushad.vo.Emp_Dept_VO;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping(value = "/getempdeptinfo/{id}")
	public Emp_Dept_VO getEmpDeptInfo(@PathVariable Integer id) {
		return employeeService.getEmpDeptInfo(id);
	}
	// http://localhost:8080/employee/getemployeebyid/{id}/and/{city}
	@GetMapping(value = "/getemployeebyid/{id}/and/{city}")
	public EmployeeDTO getEmployeeById(@PathVariable Integer id, @PathVariable String city) {
		System.out.println(id + "  " + city);
		EmployeeDTO employeeDTO = employeeService.getEmployee(id);
		return employeeDTO;
	}

	// http://localhost:8080/employee/ {data}
	@PostMapping(value = "/addemployee")
	public EmployeeDTO addEmployee(@RequestBody EmployeeDTO dto) {
		System.out.println(dto);
		return employeeService.addEmployee(dto);
	}

	@GetMapping(value = "/getemployees")
	public List<EmployeeDTO> getEmployees() {
		List<EmployeeDTO> employees = employeeService.getEmployees();
		return employees;
	}
}
