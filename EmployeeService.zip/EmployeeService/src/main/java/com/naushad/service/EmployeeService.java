package com.naushad.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.naushad.dto.EmployeeDTO;
import com.naushad.vo.Emp_Dept_VO;


public interface EmployeeService {
	
	public EmployeeDTO getEmployee(Integer id) ;
	public EmployeeDTO addEmployee(EmployeeDTO dto);
	public List<EmployeeDTO> getEmployees();
	public Emp_Dept_VO getEmpDeptInfo(Integer id);

}
