package com.naushad.service;

import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.naushad.dao.EmployeeDAO;
import com.naushad.dto.DepartmentVO;
import com.naushad.dto.EmployeeDTO;
import com.naushad.entity.EmployeeEntity;
import com.naushad.vo.Emp_Dept_VO;


@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@Override
	public Emp_Dept_VO getEmpDeptInfo(Integer id) {
		EmployeeDTO employeeDTO =  getEmployee(id);
		Integer deptid = employeeDTO.getDeptId();
		String url =  "http://localhost:2222/department/getdept/"+deptid;
		RestTemplate restTemplate = new RestTemplate();
		DepartmentVO departmentVO = restTemplate.getForObject(url, DepartmentVO.class);
		return new Emp_Dept_VO(employeeDTO, departmentVO);
	}
	
	@Override
	public EmployeeDTO getEmployee(Integer id) {
		EmployeeEntity employeeEntity = employeeDAO.getEmployee(id);
		ModelMapper mapper = new ModelMapper();
		EmployeeDTO employeeDTO = mapper.map(employeeEntity, EmployeeDTO.class);
		return employeeDTO;
	}
	
	@Override
	public List<EmployeeDTO> getEmployees() {
		List<EmployeeEntity>  employeesEntity =  employeeDAO.getEmployees();
		ModelMapper mapper = new ModelMapper();
		//mapper.typeMap(employeesEntity, List<EmployeeDTO.class>);
		//List<PostDTO> entityToDto = modelMapper.map(postEntity, new TypeToken<List<PostDTO>>(){}.getType());

		List<EmployeeDTO> postDtoList = Arrays.asList(mapper.map(employeesEntity, EmployeeDTO[].class));
		return postDtoList;
	}
	
	@Override
	public EmployeeDTO addEmployee(EmployeeDTO dto) {
		dto.setFirstName(dto.getFirstName().toUpperCase());
		ModelMapper mapper = new ModelMapper();
		EmployeeEntity  employeeEntity = mapper.map(dto, EmployeeEntity.class);
		EmployeeEntity resultEntity = employeeDAO.addEmployee(employeeEntity);
		
		return mapper.map(resultEntity,EmployeeDTO.class);
	}
}
