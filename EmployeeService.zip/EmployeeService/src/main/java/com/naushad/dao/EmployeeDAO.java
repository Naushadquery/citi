package com.naushad.dao;

import java.util.List;

import com.naushad.entity.EmployeeEntity;

public interface EmployeeDAO {

	public EmployeeEntity getEmployee(Integer id);

	public EmployeeEntity addEmployee(EmployeeEntity employeeEntity);

	public List<EmployeeEntity> getEmployees();
}
