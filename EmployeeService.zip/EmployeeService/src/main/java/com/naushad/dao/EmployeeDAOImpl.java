package com.naushad.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.naushad.entity.EmployeeEntity;
import com.naushad.repo.EmployeeRepository;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public List<EmployeeEntity> getEmployees() {
		List<EmployeeEntity> employees = employeeRepository.findAll();
		return employees;
	}
	
	@Override
	public EmployeeEntity getEmployee(Integer id) {
		return employeeRepository.findById(id).get();
	}
	
	@Override
	public EmployeeEntity addEmployee(EmployeeEntity employeeEntity) {
		return employeeRepository.save(employeeEntity);
	}
	
	
}
