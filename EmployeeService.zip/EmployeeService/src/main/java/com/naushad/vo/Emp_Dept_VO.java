package com.naushad.vo;

import com.naushad.dto.DepartmentVO;
import com.naushad.dto.EmployeeDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Emp_Dept_VO {
	
	private EmployeeDTO employeeDTO;
	private DepartmentVO departmentVO;

}
