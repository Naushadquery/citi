package com.naushad.chat.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication


public class ChatbookApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(ChatbookApplication.class, args);
	}
}
