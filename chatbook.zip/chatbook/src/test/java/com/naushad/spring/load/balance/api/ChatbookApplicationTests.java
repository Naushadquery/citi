package com.naushad.spring.load.balance.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class ChatbookApplicationTests {

	@Test
	public void contextLoads() {
	}

}
