package com.naushad.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.naushad.dto.DepartmentVO;

@FeignClient(name = "DEPARTMENT-SERVICE")
public interface DepartmentClient {
	
	@GetMapping(value="/department/getdept/{id}")
	DepartmentVO  getDepartmentById(@PathVariable("id") Integer id);
	
	@GetMapping(value="/department/getdeptbylocation/{location}")
	DepartmentVO getDepartmentByLocation(@PathVariable String location);
	
	
}
