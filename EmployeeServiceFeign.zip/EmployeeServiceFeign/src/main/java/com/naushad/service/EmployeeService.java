package com.naushad.service;

import java.util.List;

import com.naushad.dto.EmployeeDTO;
import com.naushad.vo.EmpDeptVO;


public interface EmployeeService {
	
	public EmployeeDTO getEmployee(Integer id) ;
	public EmployeeDTO addEmployee(EmployeeDTO dto);
	public List<EmployeeDTO> getEmployees();
	public EmpDeptVO getEmpDeptInfo(Integer id);

}
