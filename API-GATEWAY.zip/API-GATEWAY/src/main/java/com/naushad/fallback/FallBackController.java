package com.naushad.fallback;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackController {
	
	@GetMapping("employeeServiceFallBack")
	public String employeeFallBack() {
		return "Employee Service Not Available, try later ";
	}
	@GetMapping("departmentServiceFallBack")
	public String departmentFallBack() {
		return "Department Service Not Available, try later ";
	}

}
