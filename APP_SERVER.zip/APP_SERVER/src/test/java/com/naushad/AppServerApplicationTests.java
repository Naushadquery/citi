package com.naushad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
