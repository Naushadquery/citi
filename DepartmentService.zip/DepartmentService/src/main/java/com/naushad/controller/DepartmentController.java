package com.naushad.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.naushad.DepartmentServiceApplication;
import com.naushad.dto.DepartmentDTO;
import com.naushad.service.DepartmentService;

@RestController
@RequestMapping("/department")
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;

	@GetMapping(value="/getdept/{id}")
	public DepartmentDTO getDepartment(@PathVariable Integer id) {
		
		return departmentService.getDepartment(id);
	}
	
}
