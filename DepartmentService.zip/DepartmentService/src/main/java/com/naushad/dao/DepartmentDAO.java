package com.naushad.dao;

import java.util.Optional;

import com.naushad.entity.DepartmentEntity;

public interface DepartmentDAO {

	public Optional<DepartmentEntity> getDepartment(Integer id);

}