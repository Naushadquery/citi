package com.naushad.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.naushad.entity.DepartmentEntity;
import com.naushad.repo.DepartmentRepository;

@Repository
public class DepartmentDAOImpl implements DepartmentDAO {

	@Autowired
	private DepartmentRepository departmentRepository;
	
	
	@Override
	public Optional<DepartmentEntity> getDepartment(Integer id) {
		
		return departmentRepository.findById(id);
	}
}
