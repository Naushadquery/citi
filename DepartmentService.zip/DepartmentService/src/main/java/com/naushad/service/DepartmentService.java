package com.naushad.service;

import com.naushad.dto.DepartmentDTO;

public interface DepartmentService {

	public DepartmentDTO getDepartment(Integer id);

}
