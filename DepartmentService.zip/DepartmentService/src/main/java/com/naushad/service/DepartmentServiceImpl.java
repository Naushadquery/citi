package com.naushad.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naushad.dao.DepartmentDAO;
import com.naushad.dto.DepartmentDTO;
import com.naushad.entity.DepartmentEntity;

@Service
public class DepartmentServiceImpl implements DepartmentService{

	@Autowired
	private DepartmentDAO departmentDAO;
	
	@Override
	public DepartmentDTO getDepartment(Integer id) {
		
		Optional<DepartmentEntity> departmentEntity =  departmentDAO.getDepartment(id);
		if(departmentEntity.isPresent()) {
			DepartmentEntity departmentEntity1 = departmentEntity.get();
			ModelMapper mapper = new ModelMapper();
			return mapper.map(departmentEntity1, DepartmentDTO.class);
		}
		return null;
	}
	
}
