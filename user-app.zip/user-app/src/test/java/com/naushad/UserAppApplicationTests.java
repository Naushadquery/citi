package com.naushad;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAppApplicationTests {

	void contextLoads() {
	}

}
