package com.nau.service;

import com.nau.dao.UserDao;
import com.nau.model.User;

public class UserService {

	UserDao dao = new UserDao();

	public int verifyUser(User user) {
		System.out.println("in service verifyuser method");
		System.out.println(user);
		int userid = user.getUserid();
		User userFromDb = dao.getUserById(userid);
		int flag = 0;
		if(userFromDb!=null) {
			if(userFromDb.getPassword().equals(user.getPassword())) {
				flag = 1;
			}else {
				flag = 0;
			}
		}
		return flag;
	}

}
