package com.nau.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nau.model.User;

public class UserDao {

	public User getUserById(int userid) {
		String sql = "select * from users where userid = ?";
		String url = "jdbc:mysql://localhost:3306/citidb";
		try {
			Connection con = DriverManager.getConnection(url, "naushad", "naushad");
			System.out.println("Connected");
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, userid);
			ResultSet rs = ps.executeQuery();
			System.out.println("In DAO");
			// System.out.println(rs.next());
			User userDb = null;
			if (rs.next()) {
				String password = rs.getString("password");
				String status = rs.getString("status");
				userDb = new User(userid, password, status);
			}
			return userDb;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		new UserDao().getUserById(0);
	}
}
