package com.nau;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nau.model.User;
import com.nau.service.UserService;


@WebServlet("/login")
public class Login extends HttpServlet {  // controller
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		int userid = Integer.parseInt(request.getParameter("userid"));
		String password = request.getParameter("password");
		User user = new User(userid, password, null);
		UserService service = new UserService();
		int flag = service.verifyUser(user);
		if(flag==1) {
			request.getRequestDispatcher("welcome.html").forward(request, response);
		}else {
			out.print("<h2 class='error'>Sorry, Invalid User</h2>");
			request.getRequestDispatcher("login.html").include(request, response);

		}
		
	}
}
