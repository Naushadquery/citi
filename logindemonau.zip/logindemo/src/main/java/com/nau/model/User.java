package com.nau.model;

public class User {
	
	private int userid;
	private String password;
	private String status;
	public User() {
	
	}
	public User(int userid, String password, String status) {
		super();
		this.userid = userid;
		this.password = password;
		this.status = status;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "User [userid=" + userid + ", password=" + password + ", status=" + status + "]";
	}
	

}
